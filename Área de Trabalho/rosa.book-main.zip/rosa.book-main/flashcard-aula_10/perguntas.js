criaCartao(
    'Geografia',
    'Onde fica o deserto do Saara?',
    'No norte da África'
)

criaCartao(
    'Geografia',
    'Qual é o maior continente de expansão territorial?',
    'Ásia'
)

criaCartao(
    'Geografia',
    'Qual é a capital da Austrália?',
    'Camberra'
)

criaCartao(
    'Geografia',
    'Qual é o menor país do mundo em área?',
    'Vaticano'
)
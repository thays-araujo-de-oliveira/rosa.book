criaCartao(
    'Espanhol',
    'Como se diz: como vocẽ esta?, em espanhol?',
    'Cómo estás?'
)

criaCartao(
    'Geografia',
    'Qual a capital do Brasil?',
    'A capital do Brasil é Brasília'
)

criaCartao(
    'Geografia',
    'Qual é o maior país do mundo em área?',
    'Rússia'
)

criaCartao(
    'Lingua inglesa',
    'Como se diz oi em Inglês?',
    'Oi em ingles é HI (RAI)'
)
criaCartao(
    'Lingua inglesa',
    'Como se diz amarelo em Inglês?',
    'amarelo em ingles é yellow (RAI)'
) 